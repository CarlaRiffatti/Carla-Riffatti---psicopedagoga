import { useState } from 'react'

export default function App() {
  const [clientes, setClientes] = useState([])
  const [nome, setNome] = useState('')
  const [tipo, setTipo] = useState('')
  const [valor, setValor] = useState('')
  const [data, setData] = useState('')

  const adicionar = () => {
    if (!nome || !tipo || !valor || !data) {
      alert('Preencha todos os campos')
      return
    }

    const novo = {
      id: Date.now(),
      nome,
      tipo,
      valor,
      data
    }

    setClientes([novo, ...clientes])

    setNome('')
    setTipo('')
    setValor('')
    setData('')
  }

  return (
    <div className="container">
      <h1>Carla Riffatti - Psicopedagoga</h1>

      <div className="card">
        <h2>Novo Atendimento</h2>

        <input
          placeholder="Nome do paciente"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
        />

        <input
          placeholder="Tipo de atendimento"
          value={tipo}
          onChange={(e) => setTipo(e.target.value)}
        />

        <input
          placeholder="Valor"
          value={valor}
          onChange={(e) => setValor(e.target.value)}
        />

        <input
          type="datetime-local"
          value={data}
          onChange={(e) => setData(e.target.value)}
        />

        <button onClick={adicionar}>Salvar Atendimento</button>
      </div>

      <div className="card">
        <h2>Agenda</h2>

        {clientes.length === 0 && <p>Nenhum atendimento cadastrado.</p>}

        {clientes.map((item) => (
          <div key={item.id} className="item">
            <strong>{item.nome}</strong>
            <p>{item.tipo}</p>
            <p>R$ {item.valor}</p>
            <p>{new Date(item.data).toLocaleString('pt-BR')}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
